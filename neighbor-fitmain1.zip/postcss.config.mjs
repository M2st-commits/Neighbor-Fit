// PostCSS configuration for Tailwind CSS
// Uses the standard Tailwind CSS and Autoprefixer plugins
const config = {
plugins: ["tailwindcss", "autoprefixer"],
};

export default config;
