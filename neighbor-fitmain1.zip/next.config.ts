import type { NextConfig } from "next"

const nextConfig: NextConfig = {
  eslint: {
    // Skip linting errors during production build
    ignoreDuringBuilds: true,
  },
  typescript: {
    // Skip TypeScript errors during production build
    ignoreBuildErrors: true,
  },
  images: {
    // Disable image optimization in the next-lite runtime
    unoptimized: true,
  },
}

export default nextConfig
