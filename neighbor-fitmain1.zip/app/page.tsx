import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, MapPin, Users, BarChart3, Target, Sparkles, TrendingUp, Shield } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/20 bg-white/80 backdrop-blur-xl supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl blur opacity-20"></div>
                <MapPin className="relative h-8 w-8 text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                NeighborFit
              </h1>
            </div>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/methodology" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
                Methodology
              </Link>
              <Link href="/data" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
                Data Sources
              </Link>
              <Link href="/about" className="text-gray-600 hover:text-gray-900 font-medium transition-colors">
                About
              </Link>
              <Link href="/assessment">
                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg">
                  Get Started
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-indigo-600/5"></div>
        <div className="container mx-auto px-6 text-center relative">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-sm font-medium mb-8">
              <Sparkles className="w-4 h-4 mr-2" />
              AI-Powered Neighborhood Matching
            </div>
            <h2 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 bg-clip-text text-transparent mb-8 leading-tight">
              Find Your Perfect
              <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                Neighborhood Match
              </span>
            </h2>
            <p className="text-xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
              Discover neighborhoods that align with your lifestyle through advanced data analysis and intelligent
              matching algorithms. Make informed decisions with comprehensive insights.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/assessment">
                <Button
                  size="lg"
                  className="text-lg px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-xl hover:shadow-2xl transition-all duration-300"
                >
                  Start Assessment
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/methodology">
                <Button
                  variant="outline"
                  size="lg"
                  className="text-lg px-8 py-4 border-2 hover:bg-gray-50 bg-transparent"
                >
                  View Methodology
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">500+</div>
              <div className="text-gray-600 font-medium">Neighborhoods Analyzed</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-indigo-600 mb-2">92%</div>
              <div className="text-gray-600 font-medium">Accuracy Rate</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">15</div>
              <div className="text-gray-600 font-medium">Data Sources</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">84%</div>
              <div className="text-gray-600 font-medium">User Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Statement */}
      <section className="py-24 bg-gradient-to-b from-white to-gray-50">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h3 className="text-4xl font-bold text-gray-900 mb-6">The Neighborhood Selection Challenge</h3>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Traditional methods fall short in capturing the complexity of neighborhood-lifestyle compatibility
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-8">
              <Card className="border-0 shadow-xl bg-gradient-to-br from-red-50 to-orange-50 hover:shadow-2xl transition-all duration-300">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center text-2xl">
                    <div className="p-3 bg-red-100 rounded-xl mr-4">
                      <Target className="h-6 w-6 text-red-600" />
                    </div>
                    The Challenge
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 text-lg leading-relaxed">
                    Finding the right neighborhood involves complex, subjective factors that traditional
                    price-and-location approaches miss entirely. This leads to poor decisions and reduced satisfaction.
                  </p>
                  <ul className="mt-6 space-y-3 text-gray-600">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-red-400 rounded-full mr-3"></div>
                      Limited criteria consideration
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-red-400 rounded-full mr-3"></div>
                      Information overload
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-red-400 rounded-full mr-3"></div>
                      Subjective decision-making
                    </li>
                  </ul>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-xl bg-gradient-to-br from-green-50 to-emerald-50 hover:shadow-2xl transition-all duration-300">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center text-2xl">
                    <div className="p-3 bg-green-100 rounded-xl mr-4">
                      <TrendingUp className="h-6 w-6 text-green-600" />
                    </div>
                    Our Solution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 text-lg leading-relaxed">
                    Advanced multi-dimensional analysis combining lifestyle preferences, demographics, amenities, and
                    transportation to deliver personalized, data-driven recommendations.
                  </p>
                  <ul className="mt-6 space-y-3 text-gray-600">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-3"></div>
                      Comprehensive data integration
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-3"></div>
                      Intelligent matching algorithms
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-3"></div>
                      Transparent explanations
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">How NeighborFit Works</h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our three-step process combines advanced analytics with user-centric design
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-50 to-indigo-50 hover:shadow-2xl transition-all duration-300 group">
              <CardHeader className="pb-6">
                <div className="p-4 bg-blue-100 rounded-2xl w-fit mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Lifestyle Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 text-lg leading-relaxed mb-6">
                  Complete our comprehensive assessment covering preferences for commute, lifestyle, family needs, and
                  community characteristics.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                    Personal preferences analysis
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                    Lifestyle compatibility scoring
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-2"></div>
                    Priority weighting system
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-xl bg-gradient-to-br from-purple-50 to-pink-50 hover:shadow-2xl transition-all duration-300 group">
              <CardHeader className="pb-6">
                <div className="p-4 bg-purple-100 rounded-2xl w-fit mb-4 group-hover:scale-110 transition-transform duration-300">
                  <BarChart3 className="h-8 w-8 text-purple-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Data Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 text-lg leading-relaxed mb-6">
                  Our algorithms process comprehensive neighborhood data including demographics, safety, walkability,
                  and amenity density.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2"></div>
                    Multi-source data integration
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2"></div>
                    Real-time processing
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-purple-400 rounded-full mr-2"></div>
                    Quality assurance checks
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="border-0 shadow-xl bg-gradient-to-br from-green-50 to-emerald-50 hover:shadow-2xl transition-all duration-300 group">
              <CardHeader className="pb-6">
                <div className="p-4 bg-green-100 rounded-2xl w-fit mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Shield className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-2xl text-gray-900">Smart Matching</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 text-lg leading-relaxed mb-6">
                  Receive ranked recommendations with detailed explanations of why each neighborhood matches your unique
                  requirements.
                </p>
                <div className="space-y-2">
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-2"></div>
                    Personalized rankings
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-2"></div>
                    Detailed explanations
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 bg-green-400 rounded-full mr-2"></div>
                    Confidence scoring
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto px-6 text-center relative">
          <h3 className="text-4xl md:text-5xl font-bold mb-8">Ready to Find Your Perfect Neighborhood?</h3>
          <p className="text-xl mb-12 opacity-90 max-w-2xl mx-auto">
            Join thousands of users who have discovered their ideal community through intelligent, data-driven matching.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/assessment">
              <Button
                size="lg"
                variant="secondary"
                className="text-lg px-8 py-4 bg-white text-gray-900 hover:bg-gray-100 shadow-xl"
              >
                Take the Assessment
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/methodology">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 border-2 border-white/30 text-white hover:bg-white/10 bg-transparent"
              >
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-slate-900 to-gray-900 text-white py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-5 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-6">
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-indigo-400 rounded-xl blur opacity-20"></div>
                  <MapPin className="relative h-8 w-8 text-blue-400" />
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
                  NeighborFit
                </span>
              </div>
              <p className="text-gray-300 text-lg leading-relaxed mb-6">
                Intelligent neighborhood matching powered by advanced data analytics and machine learning algorithms.
              </p>
              <div className="flex space-x-4">
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">GH</span>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">LI</span>
                </div>
                <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                  <span className="text-sm font-bold">TW</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-6 text-blue-300 text-lg">Product</h4>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="/assessment" className="hover:text-blue-400 transition-colors">
                    Assessment
                  </Link>
                </li>
                <li>
                  <Link href="/methodology" className="hover:text-blue-400 transition-colors">
                    Methodology
                  </Link>
                </li>
                <li>
                  <Link href="/data" className="hover:text-blue-400 transition-colors">
                    Data Sources
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-6 text-green-300 text-lg">Research</h4>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="/research" className="hover:text-green-400 transition-colors">
                    User Research
                  </Link>
                </li>
                <li>
                  <Link href="/algorithm" className="hover:text-green-400 transition-colors">
                    Algorithm Design
                  </Link>
                </li>
                <li>
                  <Link href="/validation" className="hover:text-green-400 transition-colors">
                    Validation Results
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-6 text-purple-300 text-lg">Project</h4>
              <ul className="space-y-3 text-gray-300">
                <li>
                  <Link href="/about" className="hover:text-purple-400 transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <a
                    href="https://github.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-purple-400 transition-colors"
                  >
                    GitHub
                  </a>
                </li>
                <li>
                  <Link href="/documentation" className="hover:text-purple-400 transition-colors">
                    Documentation
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400 mb-4 md:mb-0">
                &copy; 2025 NeighborFit by <span className="text-blue-400 font-semibold">Akash Kumar Mishra</span>.
                Built for academic research and demonstration.
              </p>
              <div className="flex space-x-6 text-sm text-gray-400">
                <Link href="/privacy" className="hover:text-gray-300 transition-colors">
                  Privacy Policy
                </Link>
                <Link href="/terms" className="hover:text-gray-300 transition-colors">
                  Terms of Service
                </Link>
                <Link href="/contact" className="hover:text-gray-300 transition-colors">
                  Contact
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
