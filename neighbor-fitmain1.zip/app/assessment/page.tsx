"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, ArrowRight, MapPin, Sparkles } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface AssessmentData {
  budget: number[]
  commute: string
  lifestyle: string[]
  priorities: {
    walkability: number[]
    safety: number[]
    nightlife: number[]
    familyFriendly: number[]
    diversity: number[]
    greenSpace: number[]
  }
  demographics: {
    ageGroup: string
    householdSize: string
    hasChildren: boolean
    hasPets: boolean
  }
  transportation: string[]
  amenities: string[]
}

const initialData: AssessmentData = {
  budget: [2000],
  commute: "",
  lifestyle: [],
  priorities: {
    walkability: [5],
    safety: [5],
    nightlife: [5],
    familyFriendly: [5],
    diversity: [5],
    greenSpace: [5],
  },
  demographics: {
    ageGroup: "",
    householdSize: "",
    hasChildren: false,
    hasPets: false,
  },
  transportation: [],
  amenities: [],
}

export default function AssessmentPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [data, setData] = useState<AssessmentData>(initialData)
  const router = useRouter()
  const totalSteps = 5

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1)
    } else {
      // Save data and redirect to results
      localStorage.setItem("neighborfit-assessment", JSON.stringify(data))
      router.push("/results")
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const updateLifestyle = (value: string, checked: boolean) => {
    if (checked) {
      setData((prev) => ({ ...prev, lifestyle: [...prev.lifestyle, value] }))
    } else {
      setData((prev) => ({ ...prev, lifestyle: prev.lifestyle.filter((item) => item !== value) }))
    }
  }

  const updateTransportation = (value: string, checked: boolean) => {
    if (checked) {
      setData((prev) => ({ ...prev, transportation: [...prev.transportation, value] }))
    } else {
      setData((prev) => ({ ...prev, transportation: prev.transportation.filter((item) => item !== value) }))
    }
  }

  const updateAmenities = (value: string, checked: boolean) => {
    if (checked) {
      setData((prev) => ({ ...prev, amenities: [...prev.amenities, value] }))
    } else {
      setData((prev) => ({ ...prev, amenities: prev.amenities.filter((item) => item !== value) }))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-white/20 bg-white/80 backdrop-blur-xl supports-[backdrop-filter]:bg-white/60">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl blur opacity-20"></div>
                <MapPin className="relative h-8 w-8 text-blue-600" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                NeighborFit
              </h1>
            </Link>
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex items-center space-x-2 text-sm text-gray-600 bg-white/60 px-4 py-2 rounded-full">
                <Sparkles className="w-4 h-4" />
                <span>
                  Step {currentStep} of {totalSteps}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-12">
        <div className="max-w-3xl mx-auto">
          {/* Progress Section */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-3xl font-bold text-gray-900">Lifestyle Assessment</h2>
              <span className="text-sm font-medium text-gray-500 bg-gray-100 px-3 py-1 rounded-full">
                {Math.round((currentStep / totalSteps) * 100)}% Complete
              </span>
            </div>
            <Progress value={(currentStep / totalSteps) * 100} className="h-3 bg-gray-200" />
          </div>

          {/* Step 1: Budget & Basic Info */}
          {currentStep === 1 && (
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center text-white font-bold">
                    1
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">Budget & Preferences</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                      Let's start with your housing budget and commute preferences
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl">
                  <Label className="text-lg font-semibold text-gray-900 mb-4 block">Monthly Housing Budget</Label>
                  <div className="mt-4">
                    <Slider
                      value={data.budget}
                      onValueChange={(value) => setData((prev) => ({ ...prev, budget: value }))}
                      max={5000}
                      min={500}
                      step={100}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-500 mt-3">
                      <span>$500</span>
                      <span className="font-bold text-lg text-blue-600">${data.budget[0]}</span>
                      <span>$5000+</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl">
                  <Label className="text-lg font-semibold text-gray-900 mb-4 block">Preferred Commute Time</Label>
                  <RadioGroup
                    value={data.commute}
                    onValueChange={(value) => setData((prev) => ({ ...prev, commute: value }))}
                    className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4"
                  >
                    {[
                      { value: "under-15", label: "Under 15 minutes", desc: "Very close to work" },
                      { value: "15-30", label: "15-30 minutes", desc: "Short commute" },
                      { value: "30-45", label: "30-45 minutes", desc: "Moderate commute" },
                      { value: "45-60", label: "45-60 minutes", desc: "Longer commute" },
                      { value: "over-60", label: "Over 60 minutes", desc: "Extended commute" },
                    ].map((option) => (
                      <div
                        key={option.value}
                        className="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/50 transition-colors"
                      >
                        <RadioGroupItem value={option.value} id={option.value} />
                        <div>
                          <Label htmlFor={option.value} className="font-medium">
                            {option.label}
                          </Label>
                          <p className="text-sm text-gray-500">{option.desc}</p>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Demographics */}
          {currentStep === 2 && (
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center text-white font-bold">
                    2
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">Demographics & Household</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                      Help us understand your household composition
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl">
                    <Label className="text-lg font-semibold text-gray-900 mb-4 block">Age Group</Label>
                    <Select
                      value={data.demographics.ageGroup}
                      onValueChange={(value) =>
                        setData((prev) => ({
                          ...prev,
                          demographics: { ...prev.demographics, ageGroup: value },
                        }))
                      }
                    >
                      <SelectTrigger className="mt-2 h-12 bg-white/80">
                        <SelectValue placeholder="Select your age group" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="18-25">18-25 years</SelectItem>
                        <SelectItem value="26-35">26-35 years</SelectItem>
                        <SelectItem value="36-45">36-45 years</SelectItem>
                        <SelectItem value="46-55">46-55 years</SelectItem>
                        <SelectItem value="56-65">56-65 years</SelectItem>
                        <SelectItem value="65+">65+ years</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl">
                    <Label className="text-lg font-semibold text-gray-900 mb-4 block">Household Size</Label>
                    <Select
                      value={data.demographics.householdSize}
                      onValueChange={(value) =>
                        setData((prev) => ({
                          ...prev,
                          demographics: { ...prev.demographics, householdSize: value },
                        }))
                      }
                    >
                      <SelectTrigger className="mt-2 h-12 bg-white/80">
                        <SelectValue placeholder="Select household size" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Just me</SelectItem>
                        <SelectItem value="2">2 people</SelectItem>
                        <SelectItem value="3">3 people</SelectItem>
                        <SelectItem value="4">4 people</SelectItem>
                        <SelectItem value="5+">5+ people</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl">
                  <Label className="text-lg font-semibold text-gray-900 mb-4 block">Additional Information</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="flex items-center space-x-3 p-4 bg-white/60 rounded-xl">
                      <Checkbox
                        id="hasChildren"
                        checked={data.demographics.hasChildren}
                        onCheckedChange={(checked) =>
                          setData((prev) => ({
                            ...prev,
                            demographics: { ...prev.demographics, hasChildren: checked as boolean },
                          }))
                        }
                      />
                      <div>
                        <Label htmlFor="hasChildren" className="font-medium">
                          I have children
                        </Label>
                        <p className="text-sm text-gray-500">Family-friendly amenities matter</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3 p-4 bg-white/60 rounded-xl">
                      <Checkbox
                        id="hasPets"
                        checked={data.demographics.hasPets}
                        onCheckedChange={(checked) =>
                          setData((prev) => ({
                            ...prev,
                            demographics: { ...prev.demographics, hasPets: checked as boolean },
                          }))
                        }
                      />
                      <div>
                        <Label htmlFor="hasPets" className="font-medium">
                          I have pets
                        </Label>
                        <p className="text-sm text-gray-500">Pet-friendly spaces needed</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Lifestyle Preferences */}
          {currentStep === 3 && (
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center text-white font-bold">
                    3
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">Lifestyle Preferences</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                      What describes your ideal lifestyle? (Select all that apply)
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { name: "Urban Explorer", desc: "City life enthusiast", color: "from-blue-50 to-indigo-50" },
                    { name: "Quiet Suburban", desc: "Peaceful residential", color: "from-green-50 to-emerald-50" },
                    { name: "Nightlife Enthusiast", desc: "Active social scene", color: "from-purple-50 to-pink-50" },
                    { name: "Family-Oriented", desc: "Child-friendly focus", color: "from-orange-50 to-red-50" },
                    { name: "Fitness Focused", desc: "Health and wellness", color: "from-teal-50 to-cyan-50" },
                    { name: "Foodie Culture", desc: "Culinary experiences", color: "from-yellow-50 to-orange-50" },
                    { name: "Arts & Culture", desc: "Creative community", color: "from-indigo-50 to-purple-50" },
                    { name: "Tech Professional", desc: "Innovation hub", color: "from-gray-50 to-slate-50" },
                    { name: "Student Life", desc: "Academic environment", color: "from-blue-50 to-cyan-50" },
                    { name: "Remote Worker", desc: "Home office friendly", color: "from-green-50 to-teal-50" },
                    { name: "Outdoor Adventurer", desc: "Nature access", color: "from-emerald-50 to-green-50" },
                    { name: "Community Volunteer", desc: "Civic engagement", color: "from-rose-50 to-pink-50" },
                  ].map((lifestyle) => (
                    <div
                      key={lifestyle.name}
                      className={`bg-gradient-to-r ${lifestyle.color} p-4 rounded-xl hover:shadow-md transition-all duration-200`}
                    >
                      <div className="flex items-start space-x-3">
                        <Checkbox
                          id={lifestyle.name}
                          checked={data.lifestyle.includes(lifestyle.name)}
                          onCheckedChange={(checked) => updateLifestyle(lifestyle.name, checked as boolean)}
                        />
                        <div>
                          <Label htmlFor={lifestyle.name} className="font-medium text-gray-900">
                            {lifestyle.name}
                          </Label>
                          <p className="text-sm text-gray-600 mt-1">{lifestyle.desc}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Priorities */}
          {currentStep === 4 && (
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center text-white font-bold">
                    4
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">Neighborhood Priorities</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                      Rate how important these factors are to you (1 = Not Important, 10 = Very Important)
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-8">
                {Object.entries(data.priorities).map(([key, value], index) => {
                  const colors = [
                    "from-blue-50 to-indigo-50",
                    "from-green-50 to-emerald-50",
                    "from-purple-50 to-pink-50",
                    "from-orange-50 to-red-50",
                    "from-teal-50 to-cyan-50",
                    "from-yellow-50 to-orange-50",
                  ]
                  return (
                    <div key={key} className={`bg-gradient-to-r ${colors[index]} p-6 rounded-2xl`}>
                      <Label className="text-lg font-semibold text-gray-900 capitalize mb-4 block">
                        {key === "familyFriendly" ? "Family Friendly" : key === "greenSpace" ? "Green Space" : key}
                      </Label>
                      <div className="mt-4">
                        <Slider
                          value={value}
                          onValueChange={(newValue) =>
                            setData((prev) => ({
                              ...prev,
                              priorities: { ...prev.priorities, [key]: newValue },
                            }))
                          }
                          max={10}
                          min={1}
                          step={1}
                          className="w-full"
                        />
                        <div className="flex justify-between text-sm text-gray-500 mt-3">
                          <span>Not Important</span>
                          <span className="font-bold text-lg text-blue-600">{value[0]}/10</span>
                          <span>Very Important</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>
          )}

          {/* Step 5: Transportation & Amenities */}
          {currentStep === 5 && (
            <Card className="border-0 shadow-2xl bg-white/80 backdrop-blur-sm">
              <CardHeader className="pb-8">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center text-white font-bold">
                    5
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-gray-900">Transportation & Amenities</CardTitle>
                    <CardDescription className="text-lg text-gray-600">
                      What transportation options and amenities are important to you?
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-2xl">
                  <Label className="text-lg font-semibold text-gray-900 mb-4 block">Transportation Preferences</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                    {[
                      { name: "Public Transit", desc: "Buses, trains, metro" },
                      { name: "Bike Friendly", desc: "Bike lanes and paths" },
                      { name: "Car Parking", desc: "Available parking spaces" },
                      { name: "Walkable", desc: "Pedestrian-friendly" },
                      { name: "Ride Share Access", desc: "Uber, Lyft availability" },
                      { name: "Highway Access", desc: "Easy highway connections" },
                    ].map((transport) => (
                      <div
                        key={transport.name}
                        className="flex items-start space-x-3 p-4 bg-white/60 rounded-xl hover:bg-white/80 transition-colors"
                      >
                        <Checkbox
                          id={transport.name}
                          checked={data.transportation.includes(transport.name)}
                          onCheckedChange={(checked) => updateTransportation(transport.name, checked as boolean)}
                        />
                        <div>
                          <Label htmlFor={transport.name} className="font-medium">
                            {transport.name}
                          </Label>
                          <p className="text-sm text-gray-500 mt-1">{transport.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-6 rounded-2xl">
                  <Label className="text-lg font-semibold text-gray-900 mb-4 block">Important Amenities</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                    {[
                      { name: "Grocery Stores", desc: "Food shopping" },
                      { name: "Restaurants", desc: "Dining options" },
                      { name: "Coffee Shops", desc: "Cafes and coffee" },
                      { name: "Gyms", desc: "Fitness centers" },
                      { name: "Parks", desc: "Green spaces" },
                      { name: "Schools", desc: "Educational facilities" },
                      { name: "Healthcare", desc: "Medical services" },
                      { name: "Shopping", desc: "Retail stores" },
                      { name: "Libraries", desc: "Public libraries" },
                      { name: "Entertainment", desc: "Movies, theaters" },
                      { name: "Banks", desc: "Financial services" },
                      { name: "Pharmacies", desc: "Medical supplies" },
                    ].map((amenity) => (
                      <div
                        key={amenity.name}
                        className="flex items-start space-x-3 p-3 bg-white/60 rounded-lg hover:bg-white/80 transition-colors"
                      >
                        <Checkbox
                          id={amenity.name}
                          checked={data.amenities.includes(amenity.name)}
                          onCheckedChange={(checked) => updateAmenities(amenity.name, checked as boolean)}
                        />
                        <div>
                          <Label htmlFor={amenity.name} className="font-medium text-sm">
                            {amenity.name}
                          </Label>
                          <p className="text-xs text-gray-500">{amenity.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex justify-between items-center mt-12">
            <Button
              variant="outline"
              onClick={handlePrevious}
              disabled={currentStep === 1}
              className="px-6 py-3 text-lg bg-transparent"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Previous
            </Button>
            <Button
              onClick={handleNext}
              className="px-6 py-3 text-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              {currentStep === totalSteps ? "Get My Results" : "Next Step"}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
